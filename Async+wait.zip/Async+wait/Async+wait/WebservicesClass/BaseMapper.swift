//
//  BaseMapper.swift
//  hytservices
//
//  Created by Tushar on 28/07/21.
//

import UIKit
import ObjectMapper

class BaseMapper<T:Mappable>:Mappable {
    
    var data: T?
    var datalist:[T]?
    var message: String?
    var status: Bool?
    
    required init?(map: Map) { }
    
    func mapping(map: Map) {
        data <- map["resultdata"]
        datalist <- map["resultdata"]
        message <- map["message"]
        status <- map["status"]
    }
}

class UserModel : Mappable {
    
    var email: String?
    var password: String?
        
    required convenience init?(map: Map) { self.init() }
    
    func mapping(map: Map) {
        email <- map["email"]
        password <- map["password"]
    }
}
