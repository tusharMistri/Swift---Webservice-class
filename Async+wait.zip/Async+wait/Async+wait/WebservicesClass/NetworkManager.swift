//
//  NetworkManager.swift
//  hytservices
//
//  Created by kunjnewmac on 28/07/21.
//

import Foundation
import Alamofire

/// Default network envirnment, change depends on run application on particular envirment
let networkEnviroment: NetworkEnvironment = .test

/// list of envirments, Add/Remove depends on requirement
enum NetworkEnvironment {
    case test
    case production
    case stage
}

/// Response methods, Add/Remove depends on requirement
enum HttpMethods{
    case GET
    case POST
}

/// EndpointType Protocol, return fullURL
protocol EndPointType{
    var baseURL: String { get }
    var path: String { get }
}

/// list of API endpoint
enum URLEndpoint {
    case register
    case userProfile
    case login
}

/// Extension of EndPoint
extension URLEndpoint : EndPointType{
    
   /// Return your baseURL based on envirments
    var baseURL: String {
        switch networkEnviroment {
        case .test: return ""
        case .production: return ""
        case .stage: return ""
        }
    }
    
    /// Return Full URL
    var path: String{
        switch self {
        case .register:
            return baseURL + "user-signup"
        case .userProfile:
            return baseURL + "get-profile"
        case .login:
            return baseURL + "login"
        }
    }
    
    /// Map HTTPMEthod Depends on Endpoint, Default is POST
    var method: HTTPMethod {
        switch self {
        case .userProfile :
            return .get
        default:
            return .post
        }
    }
    
    /// Map Authentication header, Depends on Endpoint, Default Accesstoeken will pass
    var headers:HTTPHeaders {
        var header: HTTPHeaders = [
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
        ]
        
        switch self {
        case .userProfile :
            debugPrint(header)
            return header
        default:
            header["accessToken"] = ""
            debugPrint(header)
            return header
        }
    }
}
