//
//  WebserviceManager.swift
//  hytservices
//
//  Created by Tushar on 28/07/21.
//

import UIKit
import Alamofire
import ObjectMapper

class WebserviceManager {
    
    /// Singleton object
    static let shared : WebserviceManager = {
        let instance = WebserviceManager()
        return instance
    }()
    
    /// Convert response into your passed model
    func response<T:Mappable>(endpoint:URLEndpoint, type:T.Type, parameters:[String:Any] = [:]) async -> (status:Bool, response:BaseMapper<T>?, message:String?)? {
        self.printJsonParms(parameters)
        
        let request:DataRequest = self.urlRequest(endpoint, parameters as [String:AnyObject])
        
        do {
            let response = try await self.asyncResult(with: request)
            let objBaseMapper = Mapper<BaseMapper<T>>().map(JSONObject: response)
            return (true,objBaseMapper,"")
        } catch {
            print(error)
        }
        return (false,nil,"")
    }
}

extension WebserviceManager {
    
    /// Print Parameters
    private func printJsonParms(_ parameters:[String:Any]) {
        let jsonData = try! JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        let jsonString =  String(data: jsonData, encoding: .utf8)
        print("===== PARAMS ===== \(jsonString!)")
    }
    
    /// Return DataRequest
    private func urlRequest(_ urlPoint:URLEndpoint ,_ params:[String:AnyObject])-> DataRequest{
        let url = URL(string: urlPoint.path)!
        debugPrint("url : \(String(describing: url))")
        var urlRequst = URLRequest(url: url)
        urlRequst.headers = urlPoint.headers
        urlRequst.method = urlPoint.method
        urlRequst.timeoutInterval = 60
        let urlreq = try! URLEncoding.default.encode(urlRequst, with: params)
        let dataRequest = AF.request(urlreq)
        return dataRequest
    }
    
    /// Return webservice response with async wait
    private func asyncResult(with request:DataRequest) async throws -> Any {
        try await withUnsafeThrowingContinuation { continuation in
            request.responseJSON { response in
                switch(response.result) {
                case .success(_ ):
                    if let jsonString = String(data: response.data!, encoding: .utf8) {
                        print("===== dictResponse ===== \( jsonString)")
                    }
                    if response.response?.statusCode == 200 {
                        continuation.resume(with: response.result)
                        return
                    }else{
                        continuation.resume(returning: [:])
                        return
                    }
                case .failure(let error):
                    continuation.resume(throwing: error)
                    return
                }
            }
        }
    }
}
