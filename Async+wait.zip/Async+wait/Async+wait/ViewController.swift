//
//  ViewController.swift
//  Async+wait
//
//  Created by Tushar on 22/10/21.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad()  {
        super.viewDidLoad()
        self.loginUser()
    }
    
    /// call webservice function
    func loginUser() {
        let params = ["email":"testuser@mailinator.com","password":"12345678"]
        Task {
            let result = await WebserviceManager.shared.response(endpoint: .login, type: UserModel.self, parameters: params)
            debugPrint("status:",result?.status ?? false)
            debugPrint("userModel:",result?.response?.toJSON() ?? [:])
            debugPrint("message:",result?.message ?? "")
        }
    }
    
}

